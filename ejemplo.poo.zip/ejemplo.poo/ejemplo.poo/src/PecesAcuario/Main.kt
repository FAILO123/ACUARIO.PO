package PecesAcuario


fun main() {
    val peces: List<Pez> = listOf(Tiburon(), PezPayaso(), PezAngel())

    println("=== Bienvenido al Acuario Virtual ===")
    for (pez in peces) {
        println("El pez ${pez::class.simpleName} es de color ${pez.color}")
        if (pez is AccionPez) {
            pez.comer()
        }
        println("---------------------------")
    }

    println("Gracias por visitar el acuario!")
}
