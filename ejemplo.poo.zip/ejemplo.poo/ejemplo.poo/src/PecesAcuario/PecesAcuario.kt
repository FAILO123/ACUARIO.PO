package PecesAcuario

// Clase abstracta
abstract class Pez {
    abstract val color: String
}

// Interfaz con acción
interface AccionPez {
    fun comer()
}

// Tiburón
class Tiburon : Pez(), AccionPez {
    override val color: String = "gris"

    override fun comer() {
        println("cazar y comer peces")
    }
}

// Pez Payaso
class PezPayaso : Pez(), AccionPez {
    override val color: String = "dorado"

    override fun comer() {
        println("comer algas")
    }
}

// Pez Ángel
class PezAngel : Pez(), AccionPez {
    override val color: String = "azul"
    override fun comer() {
        println("comer plancton")
    }
}